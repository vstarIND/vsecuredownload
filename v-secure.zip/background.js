let lastAlertTime = 0;
const cooldown = 5000; // 5 seconds cooldown

function shouldShowPopup() {
  const currentTime = Date.now();
  if (currentTime - lastAlertTime > cooldown) {
    lastAlertTime = currentTime;
    return true;
  }
  return false;
}

chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    // Prevent triggering the popup on the extension’s own pages
    if (details.url.startsWith("http://") && shouldShowPopup() && !details.url.includes("popup.html")) {
      chrome.windows.create({
        url: "popup.html",
        type: "popup",
        width: 400,
        height: 300
      });
    }
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);

chrome.downloads.onCreated.addListener(function(downloadItem) {
  if (shouldShowPopup()) {
    chrome.windows.create({
      url: "popup.html",
      type: "popup",
      width: 400,
      height: 300
    });
  }
});
