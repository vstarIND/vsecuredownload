chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    if (details.url.startsWith("http://")) {
      chrome.windows.create({
        url: "popup.html",
        type: "popup",
        width: 400,
        height: 300
      });
    }
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);

chrome.downloads.onCreated.addListener(function(downloadItem) {
  chrome.windows.create({
    url: "popup.html",
    type: "popup",
    width: 400,
    height: 300
  });
});
