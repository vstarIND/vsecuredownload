chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    if (details.url.startsWith("http://")) {
      chrome.tabs.create({ url: "popup.html" });
    }
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);

chrome.downloads.onCreated.addListener(function(downloadItem) {
  chrome.tabs.create({ url: "popup.html" });
});
