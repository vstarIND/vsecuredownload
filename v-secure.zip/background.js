chrome.runtime.onInstalled.addListener(() => {
    console.log("V Secure Extension Installed");
  });
  